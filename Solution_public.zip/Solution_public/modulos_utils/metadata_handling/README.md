# Metadata Handler

![handleroverview](imgs/metadata_handler.jpeg)