# (C) Modulos AG (2019-2020). All rights reserved.
"""Jupyter Notebook utility functions."""

import os
import pathlib
from typing import Optional, Dict, Any

import pandas as pd

from modulos_utils.data_handling import data_handler as dh
from modulos_utils.metadata_handling import metadata_utils as meta_utils
from modulos_utils.previews import infer_previews


class JupyterDisplayer():
    """Helper class to display prediction results in a jupyter notebook.

    Attr:
        internal_dataset_path (str): Path to the internal dataset (hdf5).
        tmp_data_path (str): Path to tmp data.
        predictions_hdf5_path (str): Path to the hdf5 prediction data.
        prediction_path (str): Path to the file predictions.
        base_dir (str): Path to the base directory of solution folder code.
        n_samples (int): Number of samples to show.

        prediction_df (Optional[pd.DataFrame]): DataFrame of the preditions.
        input_df (Optional[pd.DataFrame]): DataFrame of the input data.
    """

    def __init__(self, base_dir: str, n_samples: int):
        """Init method of the JupyterDisplayer class.

        Args:
            base_dir (str): Path to the base directory of solution folder code.
            n_samples (int): Number of samples to show.
        """

        self.base_dir = base_dir
        self.tmp_data_path = os.path.join(self.base_dir,
                                          "output_batch_client/tmp_data_dir")
        self.predictions_hdf5_path = \
            os.path.join(self.tmp_data_path, "predictions.hdf5")
        self.internal_dataset_path = \
            os.path.join(self.tmp_data_path,
                         "check_my_dataset_output/temp.hdf5")
        self.prediction_path = os.path.join(self.base_dir,
                                            "output_batch_client/predictions")

        self.n_samples = n_samples

        self.prediction_df: Optional[pd.DataFrame] = None
        self.input_df: Optional[pd.DataFrame] = None

    @classmethod
    def construct(cls,
                  base_dir: str, n_samples: int = 10) -> "JupyterDisplayer":
        """Constructor of the Jupyter Displayer. Infers the prediction
        dataframe.

        Args:
            base_dir (str): Path to the base directory of solution folder code.
            n_samples (int): Number of samples to show.

        Returns:
            (JupyterDisplayer): Returns a fully initialized jupyter displayer.
        """

        displayer = cls(base_dir=base_dir, n_samples=n_samples)
        displayer.infer_input_df()
        displayer.infer_prediction_df()

        return displayer

    def show(self) -> pd.DataFrame:
        """Display the combined DataFrame (predictions and input) in the
        Jupyter Notebook.

        Returns:
            pd.DataFrame: Combined DataFrame (predictions and input)
        """
        merged_df = pd.merge(self.input_df, self.prediction_df, how="inner",
                             on=dh.SAMPLE_IDS)

        merged_df = self._reorder_dataframe(merged_df)

        merged_df = merged_df.style.apply(lambda x: ["background: #6daa9c"
                                          if x.name == "predictions" else ""
                                          for i in x])
        return merged_df.hide_index()

    def _reorder_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """Rearrange elements of the DataFrame such that the sample ids are in
        the first column and predictions are in the second.

        Args:
            df (pd.DataFrame): DataFrame to rearrange.
        Returns:
            pd.DataFrame: rearrange DataFrame.
        """
        column_names = df.columns.tolist()
        elements_dict = {dh.SAMPLE_IDS: 0, "predictions": 1}

        for key, value in elements_dict.items():
            tmp_el = column_names[value]
            tmp_idx = column_names.index(key)
            column_names[value] = key
            column_names[tmp_idx] = tmp_el
        return df[column_names]

    def infer_prediction_df(self) -> None:
        """Infer the prediction DataFrame, from the path to the folder of the
        predictions.
        """
        label_metadata = meta_utils.MetadataDumper().load_all_nodes(
            os.path.join(self.base_dir, "src/metadata/label_metadata.bin")
        )
        label_node_name = list(label_metadata.keys())[0]
        if label_metadata[label_node_name].is_scalar():

            dataset_reader = dh.DatasetReader(self.predictions_hdf5_path)
            predictions_dict = dataset_reader\
                .get_data_all_as_one_tensor()
            predictions_dict["predictions"] = predictions_dict["data"]\
                .reshape(-1)
            if (label_metadata[
                    label_node_name].upload_node_name.get() != label_node_name
                    and "unixtime" in label_node_name):
                predictions_dict["predictions"] = pd.to_datetime(
                    predictions_dict["predictions"], unit="s")
            predictions_dict.pop("data")
            prediction_df = pd.DataFrame(predictions_dict)

        else:
            predictions_dict = {dh.SAMPLE_IDS: [],
                                "predictions": []}
            for file_path in pathlib.Path(self.prediction_path).rglob("*.*"):
                file_name_ext = os.path.basename(file_path)
                file_name = os.path.splitext(file_name_ext)[0]
                predictions_dict["predictions"].append(file_path)
                predictions_dict[dh.SAMPLE_IDS].append(file_name)

                prediction_df = pd.DataFrame(predictions_dict)

        prediction_df = prediction_df.astype({dh.SAMPLE_IDS: str})
        self.prediction_df = prediction_df

    def infer_input_df(self) -> None:
        """Infer preview input dataset DataFrame."""

        preview_inferer = infer_previews.InferPreviews(
            internal_dataset_path=self.internal_dataset_path)
        sample_preview = preview_inferer\
            .get_sample_preview(nr_samples=self.n_samples)

        # Convert Preview to dataframe.
        df_dict: Dict[str, Any] = {dh.SAMPLE_IDS: []}
        for idx, sample_id in enumerate(sample_preview[dh.SAMPLE_IDS]):
            df_dict[dh.SAMPLE_IDS].append(str(sample_id))
            el = sample_preview["table_content"][idx]
            for key, value in el[sample_id].items():
                attr_list = df_dict.get(key, [])
                attr_list.append(value)
                df_dict[key] = attr_list
        input_df = pd.DataFrame(df_dict)
        input_df = input_df.astype({dh.SAMPLE_IDS: str})
        self.input_df = input_df
