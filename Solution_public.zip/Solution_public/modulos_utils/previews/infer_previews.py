import re
import numpy as np
from typing import List, Dict, Any

from modulos_utils.data_handling import data_handler as dh
from modulos_utils.metadata_handling import metadata_handler as meta_handler


class InferPreviews:
    """
    Infer metadata and sample previews from internal dataset file.

    Attributes:
        internal_dataset_path: path to internal dataset
        reader (dh.DatasetReader): data handling dataset reader
        node_names (list): list of node names, sorted
        nr_samples_dataset: the number of samples within the dataset
    """

    def __init__(self, internal_dataset_path: str):
        """ Init of the InferPreviews class.

        Args:
            internal_dataset_path (str): path to internal dataset file
        """
        self.internal_dataset_path = internal_dataset_path
        self.reader = dh.DatasetReader(internal_dataset_path)

        # Read in original node names (i.e. without generated datetime
        # features).
        self.node_names = self.reader.get_upload_node_names()
        if dh.SAMPLE_IDS in self.node_names:
            self.node_names.remove(dh.SAMPLE_IDS)
        self.nr_samples_dataset = self.reader.get_data_info()["n_samples"]
        self.node_names.sort()

    @staticmethod
    def _check_data_types(node_dict: Dict) -> None:
        """ Check if all entries in the dictionary are built-in python
        types. Raise TypeError if they are not.

        Args:
            node_dict (Dict): preview dictionary

        Returns:
            None

        Raises:
            TypeError: if data type is not python native
        """
        for key, value in node_dict.items():
            if not isinstance(value, (int, float, str, list)):
                raise TypeError(f"The value for key '{key}' is expected "
                                f"to have a native type. Instead its type is "
                                f"{type(value)}. "
                                )
        return None

    @staticmethod
    def _beautify_meta_preview(node_dict: Dict) -> None:
        """ Beautify the metadata preview by replacing default values and
        introducing explicit strings.

        - Replace "NaN" with "-" for class dimensions.
        - Introduce explicit data types.

        Args:
            node_dict (Dict): metadata preview dictionary for a single node

        Returns:
            Dict: preview dictionary, however default values have
            been replaced
        """
        data_type_translator = {"num": "numerical",
                                "str": "string",
                                "num_cat": "numerical & categorical",
                                "str_cat": "string & categorical",
                                }
        dssf_type_translator = {"table": "table",
                                "num": "numerical",
                                "str": "string",
                                }

        # Replace data type.
        if node_dict["data_type"] in data_type_translator:
            node_dict["data_type"] = data_type_translator[
                node_dict["data_type"]
            ]
        # Replace class dimensions.
        if np.isnan(node_dict["class_dim"]):
            node_dict["class_dim"] = "-"

        # Replace file types.
        if node_dict["dssf_type"] in dssf_type_translator:
            node_dict["dssf_type"] = dssf_type_translator[
                node_dict["dssf_type"]
            ]

        return None

    @staticmethod
    def _create_example_file_paths(sample_ids: List[str],
                                   encoded_file_path: str) -> List:
        """ Use the encoded file path from the DSSF and a list of sample IDs
        to recreate proper file paths. These are needed for nodes for which
        we cannot include the data within the sample preview (e.g. images).

        Args:
            sample_ids (List): list of sample IDs
            encoded_file_path (str): encoded file path, originally defined by
                the user in the DSSF

        Returns:
            list: list of example file paths, list has the same length as
                the input sample_ids list
        """
        example_file_paths = []
        for sample in sample_ids:
            example_file_paths.append(
                re.sub(r"\{(.*?)\}", sample, encoded_file_path)
            )
        return example_file_paths

    def get_metadata_preview(self) -> dict:
        """ Create metadata preview.

        NOTE: the format and keys being used are likely to change (BAS-378).

        Returns:
            dict: metadata preview dictionary
        """
        # NOTE: the format of the meta data preview and the keys which
        # are being used is likely to change in the future (BAS-378)
        meta_preview: Dict[str, Any] = {"table_content": [],
                                        "col_names": ["file_col",
                                                      "data_dim",
                                                      "data_type",
                                                      "class_dim",
                                                      "dssf_type",
                                                      "file_path"],
                                        "nr_nodes": 0,
                                        "id_column_flags": [],
                                        }
        # Iterate over all nodes and fill meta data preview.
        for node in self.node_names:

            # Read in metadata.
            meta_obj = meta_handler.PropertiesReader().read_from_ds_reader(
                node, self.reader
            )

            nr_nodes = meta_preview["nr_nodes"]

            node_dict = {"file_col": node,
                         "data_dim": meta_obj.node_dim.get(),
                         "data_type": meta_obj.node_type.get(),
                         "class_dim": meta_obj.nr_categories.get(),
                         "dssf_type": meta_obj.dssf_component_type.get(),
                         "file_path": meta_obj.dssf_component_file_path.get(),
                         }
            # Replace NaNs and ensure all entries are built in python types,
            # i.e. json friendly.
            self._check_data_types(node_dict)
            self._beautify_meta_preview(node_dict)
            meta_preview["table_content"].append({str(nr_nodes): node_dict})
            meta_preview["nr_nodes"] += 1
            # NOTE: previously, we had to worry about nodes containing sample
            # IDs or not. In the case of the internal dataset, this is no
            # longer the case. Nodes which contain sample IDs are no longer
            # being added as regular nodes.
            meta_preview["id_column_flags"].append(0)

        return meta_preview

    def get_sample_preview(self, nr_samples: int = 3) -> dict:
        """ Create sample preview.

        NOTE: the format and keys being used are likely to change (BAS-378).

        Args:
            nr_samples (int): the number of samples to include in the preview

        Returns:
            dict: the sample preview dictionary
        """
        # Ensure that the number of samples which are meant to be added to the
        # preview is not > the total number of samples in the dataset.
        if nr_samples > self.nr_samples_dataset:
            nr_samples = self.nr_samples_dataset

        # Get sample ids.
        sample_ids = next(
            self.reader.get_data_of_node_in_batches(
                dh.SAMPLE_IDS, batch=nr_samples)).tolist()

        # NOTE: the format of the sample preview and the keys which are being
        # used is likely to change in the future (BAS-378)
        sample_preview: Dict[str, Any] = {"table_content": [],
                                          "metadata": {"file_col": {},
                                                       "file_path": {},
                                                       "nr_nodes": 0},
                                          dh.SAMPLE_IDS: sample_ids,
                                          }
        for sample in sample_ids:
            sample_preview["table_content"].append({sample: {}})

        for node in self.node_names:

            nr_nodes = sample_preview["metadata"]["nr_nodes"]

            # Read in metadata.
            meta_obj = meta_handler.PropertiesReader().read_from_ds_reader(
                node, self.reader
            )

            if meta_obj.node_dim.is_default():
                raise ValueError(f"Node {node}: '{meta_obj.node_dim.key}' "
                                 f"is equal to its default value. The sample "
                                 f"preview cannot be computed.")

            # Add data.
            node_dim = meta_obj.node_dim.get()
            if node_dim == [1]:
                # Read in data for single values and remove empty dimension
                # for scalars. Convert to list.
                node_data = next(
                    self.reader.get_data_of_node_in_batches(
                        node, batch=nr_samples))[:, 0].tolist()
            elif len(node_dim) == 1:
                # Read in data for single values. Convert to list.
                node_data = next(
                    self.reader.get_data_of_node_in_batches(
                        node, batch=nr_samples)
                ).tolist()
            else:
                # Use encoded file path and sample IDs to create file path
                # examples.
                node_data = self._create_example_file_paths(
                    sample_ids, meta_obj.dssf_component_file_path.get()
                )
            for index, sample in enumerate(sample_ids):
                sample_preview["table_content"][index][sample][node] \
                    = node_data[index]

            # Add metadata.
            sample_preview["metadata"]["file_col"][str(nr_nodes)] = node
            sample_preview["metadata"]["file_path"][str(nr_nodes)] = \
                meta_obj.dssf_component_file_path.get()

            sample_preview["metadata"]["nr_nodes"] += 1

        return sample_preview
