# (C) Modulos AG (2019-2020). All rights reserved.
"""This file contains the functions to convert or edit timestamps."""
import numpy as np
import pandas as pd
from typing import Union, Dict, List


TIME_FEATURES_CAT: Dict[str, List[int]] = {
    "year": [], "day": list(range(1, 32)), "hour": list(range(24)),
    "month": list(range(1, 13)), "weekday": list(range(7)), "unixtime": []}
TIME_FEATURES_VALUES = {
    "year": lambda dt: dt.year, "day": lambda dt: dt.day,
    "hour": lambda dt: dt.hour, "month": lambda dt: dt.month,
    "weekday": lambda dt: dt.weekday,
    "unixtime": lambda dt: dt.astype(np.int64) // 10**9}


def parse_datetime_in_dataframe_column(
        df: pd.DataFrame, column_name: Union[int, str]) -> None:
    """Parse a column of a pandas.DataFrame to datetime and replace it with it.
    If the function fails, the thrown exception has to be caught by the
    function caller.

    Args:
        df (pd.DataFrame): DataFrame with a parsable datetime strings.
        column_name (Union[int, str]): Name or index of the column to parse.

    Raises:
        TypeError: Raised if columns contains no strings.
        ValueError: Raised if the parsed date is out of range or the format is
            not know.

    """
    df[column_name] = pd.to_datetime(
        df[column_name], infer_datetime_format=True)


def compute_features_from_timestamp(
        timestamps: pd.DatetimeIndex) -> Dict[str, List[int]]:
    """Compute the features defined in TIME_FEATURES_VALUES.

    Args:
        timestamps (pd.DatetimeIndex): The timestamps.

    Returns:
        Dict[str, List[int]]: Newly created features.
    """
    features: Dict[str, List[int]] = {}
    for feature, get_values in TIME_FEATURES_VALUES.items():
        features[feature] = list(get_values(timestamps))
    return features


def get_datetime_node_names(datetime_name: str) -> List[str]:
    """Return a list with all the names of the generated subfeature
    of the datetime node.

    Args:
        datetime_name (str): Name of the datetime node.

    Returns:
        List[str]: List of the names of the subfeatures of the datetime node.
    """
    return [get_datetime_node_name_for_feature(
        datetime_name, f) for f in TIME_FEATURES_VALUES]


def get_datetime_node_name_for_feature(datetime_name: str,
                                       feature: str) -> str:
    """Return a string with the name of the generated subfeature
    of the datetime node.

    Args:
        datetime_name (str): Name of the datetime node.
        feature (str): Name of the feature.

    Returns:
        str: Name of the subfeature of the datetime node.
    """
    return f"{datetime_name}__{feature}"
