# (C) Modulos AG (2019-2020). All rights reserved.
"""Custom exceptions for the dataset converter Class.
"""


class DatasetOutputWriteError(Exception):
    """Exception for the case where the output dataset is not valid.
    """
    pass


class DataFileInexistentError(Exception):
    """Exception for the case where the output dataset is not valid.
    """
    pass


class SampleIdsInconsistentError(Exception):
    """Exception for the case where the output dataset is not valid.
    """
    pass


class MODOutputWriteError(Exception):
    """Exception for the case where the output dataset is not valid.
    """
    pass


class DatasetMetadataError(Exception):
    """Exception for the case where input metadata is empty in the hdf5.
    """
    pass


class DatasetConverterInternalError(Exception):
    """Exception for internal errors of the DatasetConverter Class.
    """
    pass
