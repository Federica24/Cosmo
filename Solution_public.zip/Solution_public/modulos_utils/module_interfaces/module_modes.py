# (C) Modulos AG (2019-2020). All rights reserved.
from enum import Enum, unique


@unique
class ModuleModes(Enum):
    """Enum class for modes of models, feature extractors and optimizers.
    """
    TRAINING = "training"
    VALIDATION = "validation"
    NONE = None
