# (C) Modulos AG (2019-2020). All rights reserved.
from enum import Enum, unique


@unique
class ModuleType(Enum):
    """Enum class for module type.
    """
    FEATURE_EXTRACTOR = "feature_extractors"
    MODEL = "models"
    OPTIMIZER = "optimizers"
    OBJECTIVE = "objectives"
    SPLIT_STRATEGY = "split_strategies"
    ASSESSOR = "assessors"
    DATASET_STATS = "dataset_stats"
