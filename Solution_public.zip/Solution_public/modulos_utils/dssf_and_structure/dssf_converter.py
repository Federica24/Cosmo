# (C) Modulos AG (2019-2020). All rights reserved.
"""Converter function from old DSSF format to DSSF version 0.1.
"""
import argparse
import json
import os
import sys
import logging
from typing import Dict, Any, List

from modulos_utils.dssf_and_structure import DSSFErrors
from modulos_utils.dssf_validation import check_my_dssf


def convert_legacy_to_latest_stable_dssf(
        legacy_dssf: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Try to convert the legacy DSSF format to the latest version and print
    it. If it is not in the legacy format, it will throw an error.

    Args:
        legacy_dssf (Dict[str, Dict[str, Any]]): DSSF in legacy format.

    Raises:
        DSSFFormatError: Raised if the type is not specified in the legacy
            version.
        DSSFVersionError: Raised if the DSSF is not in a known format.
    """
    if (isinstance(legacy_dssf, dict) and list(legacy_dssf.keys()) == ["{id}"]
            and isinstance(legacy_dssf["{id}"], dict)):
        dssf = legacy_dssf["{id}"]
        dssf_list: List[Dict[str, Any]] = []
        for component in dssf:
            dssf_dict_new: Dict[str, Any] = {}
            if ("node_name" in dssf[component] and
                    isinstance(dssf[component]["node_name"], str)):
                name = dssf[component]["node_name"]
                dssf_dict_new["name"] = name
            else:
                dssf_dict_new["name"] = "Unknown_" + component
                logging.warning(f"No name for node '{component}'. A "
                                "default name is used.")
            path = dssf[component]["path"]
            dssf_dict_new["path"] = path
            # Find the type.
            if "num" in component:
                node_type = "num"
            elif "str" in component:
                node_type = "str"
            elif "mixed" in component:
                node_type = "table"
            else:
                raise DSSFErrors.DSSFFormatError(
                    "Format is not valid -> not able to convert DSSF.")
            dssf_dict_new["type"] = node_type
            # Find if it is categorical.
            if node_type != "table":
                if "cat" in component:
                    categorical = "true"
                else:
                    categorical = "false"
                dssf_dict_new["optional_info"] = {"categorical":
                                                  categorical}
            if node_type == "table":
                if "{id}" in dssf[component]:
                    sample_id_column = dssf[component]["{id}"]
                    dssf_dict_new["optional_info"] = {"sample_id_column":
                                                      sample_id_column}
            dssf_list.append(dssf_dict_new)
        dssf_list.append({"_version": "0.1"})
        return dssf_list
    else:
        raise DSSFErrors.DSSFVersionError("Unknown DSSF format!")


if __name__ == "__main__":

    description = ("Convert legacy DSSF into version '0.1'.\nRead dssf file, "
                   "test the version: if it is version '0.1' -> do nothing; "
                   "elif it is not the legacy version -> throw error; else "
                   "rename the source, if it is called "
                   "'dataset_structure.json', to '*_legacy.json, convert it to"
                   " the version '0.1' and save it in the same directory to "
                   "'dataset_structure.json'.")
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("legacy_dssf_path", type=str,
                        help="Path to the legacy DSSF.")
    args = parser.parse_args()

    # Read dssf.
    if not os.path.isfile(args.legacy_dssf_path):
        raise FileNotFoundError("There is no file in "
                                f"'{args.legacy_dssf_path}'")
    try:
        with open(args.legacy_dssf_path) as f:
            legacy_dssf = json.load(f)
    except json.JSONDecodeError as e:
        raise DSSFErrors.DSSFFormatError(f"Could not read json: {e}")

    # Check if the dssf version is already the latest.
    if isinstance(legacy_dssf, list):
        if ("_version" in legacy_dssf[-1].keys()
                and legacy_dssf[-1]["_version"] == "0.1"):
            print("The DSSF seems to be already in version '0.1'.\n"
                  "The `check_my_dssf` function is now run on it to confirm "
                  "that it is valid:\n\n")
            check_my_dssf.check_my_dssf(args.legacy_dssf_path)
            sys.exit()
        else:
            raise DSSFErrors.DSSFFormatError(
                "The DSSF could have the latest version, but the version "
                "specifier is missing.")

    # Convert dssf.
    new_dssf = convert_legacy_to_latest_stable_dssf(legacy_dssf)

    # Find file to save new dssf.
    json_dir = os.path.dirname(args.legacy_dssf_path)
    if os.path.basename(args.legacy_dssf_path) == "dataset_structure.json":
        os.rename(args.legacy_dssf_path,
                  os.path.join(json_dir, "dataset_structure_legacy.json"))
    new_file = os.path.join(json_dir, "dataset_structure.json")

    # Ask user what to do, if there is another file with the same name.
    if os.path.isfile(new_file):
        answered = False
        while not answered:
            answer = input("There is already a `dataset_structure.json`. Do "
                           "you want to overwrite it? [Y/n]").lower()
            choice = (not answer or answer in ["y", "yes"])
            answered = choice
            if not choice:
                if answer not in ["n", "no"]:
                    print("Please respond with 'y' or 'n'.")
                else:
                    answered = True
        if not choice:
            print("Aborted! New DSSF not saved.")
            sys.exit()
    with open(new_file, "w") as f:
        json.dump(new_dssf, f, indent=4)
    print("DSSF successfully converted from 'legacy' to '0.1' and saved in "
          f"'{new_file}'!")
    print("Good bye!\n")
