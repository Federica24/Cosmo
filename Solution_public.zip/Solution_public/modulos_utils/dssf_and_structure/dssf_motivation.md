# structure/DSSF: refactor

> **Short summary**:
> Refactor structure code to make it more efficient, user friendly and extendable.
> Change DSSF to be more user friendly.

---

**Author(s)**:

- Michael
- (Anna)

**Discussed with**:

- Dennis
- Dominic
- Romain

**Related ticket(s)/Related epic**:

- `structure`

**Feature branch name**:

- `BAS-544-DSSF-structure-feature-branch`

**Timeline**:

- start date: early Feburary 2020
- anticipated end¹ date: end of Feburary 2020
- intended release: v0.3

¹everything merged into dev

---

## What is the goal

We aim to refactor the structure and DSSF code, in a way which makes it easier for the user to create his/her own DSSF and which makes saving the data in our standardize internal dataset format (hdf5) more efficient. Our goal is also to make it easier to add additional and new datatypes to the DSSF.

New features:

- check my DSSF function: can be used by the user before uploading his/her data to the platform
- include DSSF version number
- converter: convert from json to object and from object to json; convert past DSSF versions to current one
- shuffle dataset upon upload
- check my dataset function: can be run locally, before user uploads data to system

## Why is it necessary

The current implementation of the DSSF/structure code suffers from various problems:

- the way we save the datat in hdf5 is inefficient, especially for tables
- the DSSF format is unintuitive and difficult to understand for the user
- the dataset is not shuffled upon upload (this is difficult to do later on, due to the nature of hdf5)
- the data handling is messy: some nodes are read in as objects and not as strings, requirements for hdf5 and json should be handled better
- the current implementation makes adapting the DSSF (e.g for datetime) tricky
- the error messages which are shown to the user should be more precise

## What is the trickiest part

Efficiently handling all the different component and node types and making the code extendable.

## The biggest change will be

Everything :)

## Roadmap

- `BAS-583`: DSSFInterpreter class to read in `dataset_structure.json` files
- `BAS-479`: `check_my_dssf` function
- `BAS-584`: Implement family of Component classes to read, validate and save components
- `BAS-587`: `check_my_dataset` function
- `BAS-585`: DatasetSaver class to manage the read in, validation and saving of datasets
- `BAS-586`: compute_metadata function in DatasetSaver
- `BAS-588`: DSSF Version Converter

## Open questions

- Node names for tables: The user will define a component name in the DSSF. For tables, should the node names be: `component_name_column_name` or `column_name`; both options have advantages and disadvantages; consider implications for the download
- How do we save timeseries data in hdf5?

## Future vision

- Support datetime
- Support timeseries
