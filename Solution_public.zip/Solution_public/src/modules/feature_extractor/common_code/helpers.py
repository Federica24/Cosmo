# (C) Modulos AG (2019-2020). All rights reserved.
import math
import numpy as np
from typing import List, Dict, Union, Generator

from modulos_utils.metadata_handling import metadata_properties as meta_prop
from modulos_utils.convert_dataset import dataset_return_object as d_obj

DictOfLists = Dict[str, List]
DictOfMetadata = Dict[str, meta_prop.AllProperties]
GenOfDicts = Generator[dict, None, None]
ArrayDict = Dict[str, np.array]


class PCAError(Exception):
    """Error in the PCA FE.
    """
    pass


def check_input_batch(input_data: DictOfLists, metadata: DictOfMetadata,
                      node_list: List[str]) -> None:
    """Check input types and assumptions.

    Args:
        input_data (DictOfLists): Dictionary of lists.
        metadata (DictOfMetadata): Metadata dict that was saved in the weights.
        node_list(List[str]): List of required node names.

    Raises:
        PCAError: Error, if the input data type is wrong.

    """
    # Check input type.
    if not isinstance(input_data, dict):
        raise PCAError(
            "Input to PCA Feature Extractor must be a dictionary."
        )
    for key in input_data.keys():
        if not isinstance(key, str):
            raise PCAError(
                "Input to PCA Feature Extractor must be a dictionary "
                "with string type keys."
            )
    for required_node in node_list:
        if required_node not in input_data:
            raise PCAError(
                f"Node {required_node} (that was present during training) is "
                "missing in the input."
            )
    for key, value in input_data.items():
        if key not in metadata:
            continue
        if not isinstance(value, list):
            raise PCAError(
                "Input to PCA Feature Extractor must be a dictionary "
                "with string type keys and list type values. However node "
                f"{key} is of type {type(value)}."
            )
        numpy_dtype = np.array(value).dtype
        if not (numpy_dtype == int or numpy_dtype == float):
            raise PCAError(
                f"The data type of node {value} is wrong. The PCA "
                "feature extractor assumes that all nodes are numerical.")


def listify(list_or_scalar: Union[List, str, int, float]) -> List:
    """Convert scalars to lists and return lists without changing them. Note
    that mypy would not allow that case where the input data of the FE is not a
    list, but we can not assume that the user using the online client performs
    type checks.

    Args:
        list_or_scalar (Union[List, str, int, float]): List or python native
            scalars.

    Returns:
        List: List of str/int/float.
    """
    # THIS FUNCTION IS A COPY PASTE AND OCCURS IN ALL THE HELPERS OF THE TABLE
    # PREP FAMILY, ImgIdentityCatIntEnc AND PCA.
    if not isinstance(list_or_scalar, list):
        return [list_or_scalar]
    else:
        return list_or_scalar


def get_all_samples_from_generator(
        input_samples: d_obj.DatasetGenerator) -> dict:
    """Iterate over all samples of generator and create a dictionary containing
    all nodes and all samples for each node.

    Args:
        input_samples (d_obj.DatasetGenerator): Dictionary which contains all
            samples for each node name.

    Returns:
        dict: Dictionary containing the batch size with the key "batch_size"
            and the data (all samples) with the key "all_samples".
    """
    # THIS FUNCTION IS A COPY PASTE AND OCCURS IN ALL THE HELPERS OF THE TABLE
    # PREP FAMILY, ImgIdentityCatIntEnc AND PCA.

    # Note that we don't perform  checks to raise explicit exceptions in this
    # function because this whole function will be removed in BAS-603 and the
    # checks are performed after this functions call.
    batch_size = 0
    all_samples: DictOfLists = {}
    for batch in input_samples:
        for key, values in batch.items():
            values_list = listify(values)
            if key in all_samples:
                all_samples[key] += values_list
            else:
                all_samples[key] = values_list
                batch_size = len(values_list)
    return {"all_samples": all_samples, "batch_size": batch_size}


def get_generator_over_samples(all_samples: ArrayDict,
                               batch_size: int) -> GenOfDicts:
    """Return a generator over batches of samples, given all the data.

    Args:
        all_samples (DictOfLists): A dictionary with the node names as keys
            and the node data for all samples as values.
        batch_size (int): Batch size.

    Returns:
        Array: Generator over batches of samples.
    """
    # THIS FUNCTION IS A COPY PASTE AND OCCURS IN ALL THE HELPERS OF THE TABLE
    # PREP FAMILY, ImgIdentityCatIntEnc AND PCA.
    n_samples_total = len(list(all_samples.values())[0])
    n_iterations = math.ceil(n_samples_total / batch_size)
    for i in range(n_iterations):
        sample_dict = {}
        for node_name in all_samples.keys():
            sample_dict[node_name] = all_samples[node_name][
                i * batch_size: (i + 1) * batch_size]
        yield sample_dict
