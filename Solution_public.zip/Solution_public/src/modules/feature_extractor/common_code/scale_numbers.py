# (C) Modulos AG (2019-2020). All rights reserved.
# THIS FILE IS DUPLICATED IN ALL TABLE PREP FEATURE EXTRACTORS. SO IF YOU
# CHANGE SOMETHING HERE, YOU HAVE TO COPY PASTE TO EVERY MEMBER OF THE TABLE
# PREP FAMILY!
"""This file contains classes to scale numerical columns of tables.
"""
import sklearn.preprocessing as skprep
import numpy as np
from typing import List, Union, Any


class StandardScaler:
    """
    Class that performs standard scaling of numerical vectors/scalars.
    """

    def __init__(self) -> None:
        """
        Initialize class.
        """
        self._scaler = skprep.StandardScaler()

    def __eq__(self, other: Any) -> bool:
        """Implement equality operator.

        Args:
            other (Any): Any object to compare with.

        Returns:
            bool: True if the object is equal to the instance of this class.
        """
        mean_equal = False
        scale_equal = False
        if not isinstance(other, StandardScaler):
            return False
        if not hasattr(self._scaler, "mean_") and not \
                hasattr(other._scaler, "mean_"):
            mean_equal = True
        if hasattr(self._scaler, "mean_") and hasattr(other._scaler, "mean_"):
            mean_equal = other._scaler.mean_ == self._scaler.mean_
        if not hasattr(self._scaler, "scale_") and not \
                hasattr(other._scaler, "scale_"):
            scale_equal = True
        if hasattr(self._scaler, "scale_") and \
                hasattr(other._scaler, "scale_"):
            scale_equal = other._scaler.scale_ == self._scaler.scale_
        return mean_equal and scale_equal

    def fit(self, X: Union[List[int], List[float]]) -> "StandardScaler":
        """Fit a standard scaler to a set of data.

        Args:
            X (Union[List[int], List[float]]): Input list.

        Returns:
            StandardScaler: Class itself.
        """
        data = np.array(X, dtype=float)
        self._scaler.fit(data)
        return self

    def transform(self, X: Union[List[int], List[float]]) -> List[float]:
        """Apply standard scaling to a list of input values.

        Args:
            X (Union[List[int], List[float]]): Input list.
        """
        data = np.array(X, dtype=float)
        result_exp = self._scaler.transform(data)
        return np.reshape(result_exp, -1).tolist()
