# (C) Modulos AG (2019-2020). All rights reserved.
"""DSSFComponent is a representation of a component in the DSSF.

It is used to determine the default values for the missing keys, validate the
optional keys and read and save the data to the internal dataset.
"""
from abc import ABC, abstractmethod
import glob
import itertools
import numpy as np
import os
import pandas as pd
from typing import List, Dict, Any, Iterator, Optional, Union

from modulos_utils.config import config
from modulos_utils.dssf_and_structure import read_data
from modulos_utils.data_handling import data_handler as dh
from modulos_utils.dssf_and_structure import dssf_utils
from modulos_utils.metadata_handling import metadata_handler as meta_handler
from modulos_utils.metadata_handling import metadata_properties as meta_prop
from modulos_utils.dssf_and_structure import DSSFErrors
from modulos_utils.dssf_and_structure import structure_logging as struc_log
from modulos_utils.datetime_utils import datetime_utils


ID_PLACEHOLDER = "{id}"
COLUMN_LIMIT = 500
AUTOMATIC_DATETIME_HEURISTIC_ON = config.get_datetime_heuristic_status()

# Note that this batch size is ignored for images, as a bug fix. They have
# their own default batch size of 100. This needs to be reworked: BAS-826
BATCH_SIZE_GB = 10**9


def compute_component_batch_size(
        batch_size_gb: int, path_list: List[str], n_samples_tot: int) -> int:
    """Compute the batch size (in number of samples) to load a dataset
    component consisting of all the files in path_list, such that on batch has
    the size batch_size_gb GB.

    Args:
        batch_size_gb (int): Batch size in gigabytes.
        path_list (List[str]): List of paths that belong to the component.
        n_samples_tot (int): Total number of samples of the dataset.

    Returns:
        int: Batch size (number of samples in the batch):
    """
    n_batches_float = os.path.getsize(path_list[0]) * len(path_list) \
        / float(BATCH_SIZE_GB)
    batch_sample_count = int(n_samples_tot / n_batches_float)
    return batch_sample_count


class ComponentClass(ABC):
    """
    This is the abstract base class for classes reading in the data.
    """
    defaults: Dict[str, Optional[str]] = {}

    def __init__(
            self, comp: Dict[str, Any], dataset_dir_path: str, batch_size: int,
            logging_purpose: struc_log.LoggingPurpose) -> None:
        self.name: str = comp["name"]
        self.path: Any = comp["path"]
        self.type: str = comp["type"]
        self.dataset_dir_path: str = dataset_dir_path
        self.batch_size: int = batch_size
        self.opt_info: Dict[str, Any] = (comp["optional_info"]
                                         if "optional_info" in comp else {})
        self.sample_ids: List[str] = []
        self.data_generator: Iterator[dict]
        self.allowed_file_types: List[str] = []
        self.ignored_keys: List[str] = []
        self.wrong_type_keys: List[str] = []
        self._set_defaults_and_check_()
        self.logging_purpose = logging_purpose
        self.component_logger = struc_log.ComponentLoggingManager(
            self.name, logging_purpose)
        self.metadata: Dict[str, meta_prop.AllProperties] = {}
        return None

    def _set_defaults_and_check_(self) -> None:
        """Checks if there are keys with wrong values and replaces them with
        default values, checks if there are undefined keys and deletes them
        and at last set default values for all missing keys.
        """
        for info in list(self.opt_info):
            if info in self.defaults:
                if not self._check_type_opt_info(info):
                    self.wrong_type_keys.append(info)
                    self.opt_info[info] = self.defaults[info]
            else:
                self.opt_info.pop(info)
                self.ignored_keys.append(info)
        for info in self.defaults:
            if info not in self.opt_info:
                self.opt_info[info] = self.defaults[info]
        return None

    @abstractmethod
    def _check_type_opt_info(self, info: str) -> bool:
        """Used to test that the value of the optional key is
        correct. This function is implemented in the child classes.

        Args:
            info (dict): the optional keys
        """
        pass

    def get_sample_ids(self) -> List[str]:
        """Return the sample ids.

        If the data generator is not initialized, it will do that and find the
        ids in the initialization.

        Returns:
            List[str]: List of samples ids as strings.
        """
        if self.sample_ids == []:
            self.prepare_data_for_reading()
        return self.sample_ids

    @abstractmethod
    def prepare_data_for_reading(self) -> int:
        """Prepare the generator to read the data.

        Check if the data is correct, prepare the batches and generator and
        get the sample ids.

        Returns:
            int: number of samples
        """
        pass

    @abstractmethod
    def save_component(self, h5_writer: dh.DatasetWriter,
                       shuffled_positions: List[int],
                       nodes_to_be_saved: Optional[List[str]]) -> None:
        """Use the generator to read all data and save it in the given sequence.

        The list `shuffled_positions` describes the way the data is shuffled.
        The `n`th entry is the index of the input data sample which is saved at
        position `n` in the internal dataset.

        Args:
            h5_writer (dh.DatasetWriter): h5 datahandler writer instance
            shuffled_positions (List[int]): sequence to save the data
            nodes_to_be_saved (Optional[List[str]]): None if all data should be
                saved, else the names of the nodes that should be saved
        """
        pass

    def _check_file_extension(self) -> None:
        """Check if the file extension is allowed for the specific component
        type.

        Raises:
            DSSFErrors.WrongExtension: Raised if the file extension is not
                allowed.
            TypeError: Raised if path value has the wrong type.
        """
        if isinstance(self.path, str):
            ext = os.path.splitext(self.path)[1]
            if ext not in self.allowed_file_types:
                raise DSSFErrors.WrongExtensionError(
                    f"The file extension '{ext}' of component '{self.name}' "
                    "can not be used for component type "
                    f"{self.__class__.__name__}.\n")
            return None
        elif isinstance(self.path, list):
            for path in self.path:
                ext = os.path.splitext(path)[1]
                if ext not in self.allowed_file_types:
                    raise DSSFErrors.WrongExtensionError(
                        f"The file extension '{ext}' of component "
                        f"'{self.name}' can not be used for "
                        "component type "
                        f"{self.__class__.__name__}.\n")
        else:
            raise TypeError("The path argument in the dssf has to be a string "
                            f" or a list. '{self.path}' is neither.")
        return None

    def _get_sample_ids_from_paths(self, paths: List[str]) -> List[str]:
        """Return the list of samples ids from a list of paths.

        Args:
            paths (List[str]): List of absolute paths containing the
                `ID_PLACEHOLDER`

        Returns:
            List[str]: sample ids as a list of strings
        """
        file_fix = os.path.join(self.dataset_dir_path,
                                self.path).split(ID_PLACEHOLDER)
        sample_ids: List[str] = []
        for path in paths:
            sample_ids.append(
                path.replace(file_fix[0], "", 1).replace(file_fix[1], ""))
        return sample_ids

    def _set_datetime_metadata(self, node: str, values: np.array,
                               h5_writer: dh.DatasetWriter,
                               subfeature: Optional[str] = None) -> None:
        """Compute the metadata of a new datetime sub node.

        Args:
            node (str): Name of the created datetime node.
            values (np.array): Values of the new node.
            h5_writer (dh.DatasetWriter): h5 datahandler writer instance.
            subfeature (Optional[str]): Name of the datetime subfeature. If the
                node is the datetime stamp itself, this is None.
        """
        is_orig = subfeature not in datetime_utils.TIME_FEATURES_CAT
        is_cat = (datetime_utils.TIME_FEATURES_CAT[subfeature] != []
                  if not is_orig and subfeature is not None else False)
        self.metadata[node] = meta_prop.AllProperties()
        self.metadata[node].dssf_component_file_path.set(
            self.path if not isinstance(self.path, list)
            else sorted(self.path)[0]
        )
        self.metadata[node].dssf_component_name.set(self.name)
        self.metadata[node].dssf_component_type.set(self.type)
        node_type = "num" + is_cat * "_cat" if not is_orig else "datetime"
        self.metadata[node].upload_node_type.set(node_type)
        self.metadata[node].upload_node_name.set(node.split("__")[0])
        self.metadata[node].node_type.set(node_type)
        self.metadata[node].upload_node_dim.set([1])
        self.metadata[node].node_dim.set([1])
        if is_cat and subfeature is not None:
            unique_values = datetime_utils.TIME_FEATURES_CAT[subfeature]
            self.metadata[node].upload_nr_categories.set(len(unique_values))
            self.metadata[node].nr_categories.set(len(unique_values))
            self.metadata[node].upload_unique_categories.set(unique_values)
            self.metadata[node].unique_categories.set(unique_values)
        if not is_orig:
            self.metadata[node].upload_max.set(np.max(values))
            self.metadata[node].max.set(np.max(values))
            self.metadata[node].upload_min.set(np.min(values))
            self.metadata[node].min.set(np.min(values))
        meta_handler.PropertiesWriter().write_to_ds_writer(
            self.metadata[node], node, h5_writer)
        return None

    def _save_datetime(self, name: str,
                       shuffling_dict: Dict[int, int],
                       h5_writer: dh.DatasetWriter) -> None:
        """Read the column with the time stamp, create new nodes and save them.

        Args:
            name (str): Name of the column or component containing the
                timestamp.
            shuffling_dict (Dict[int, int]): Shuffling order of the hdf5.
            h5_writer (dh.DatasetWriter): h5 datahandler writer instance.
        """
        time_stamps = self._get_time_stamp(name)

        dateTime_shuffled: Dict[int, np.datetime64] = {}
        for n, value in enumerate(time_stamps):
            dateTime_shuffled[shuffling_dict[n]] = value
        timestamps = [dateTime_shuffled[key] for key in
                      sorted(dateTime_shuffled)]
        # Add timestamp to internal dataset.
        h5_writer.add_datetime(name, np.array(timestamps))
        self._set_datetime_metadata(name, np.array(timestamps), h5_writer)
        # Compute and add new features from timestamp to internal dataset.
        df_timestamps = pd.to_datetime(timestamps)
        new_features = datetime_utils.compute_features_from_timestamp(
            df_timestamps)
        for subfeature, values in new_features.items():
            node_name = datetime_utils.get_datetime_node_name_for_feature(
                name, subfeature)
            h5_writer.add_data_to_node(node_name, np.array(values))
            self._set_datetime_metadata(node_name, np.array(values),
                                        h5_writer, subfeature)
        return None

    @abstractmethod
    def _get_time_stamp(self, name: str) -> List[np.datetime64]:
        """Get the time stamp from a column or component using the reader.

        Args:
            name (str): Name of the column or component containing the
                timestamp.

        Returns:
            List[np.datetime64]: List of all time stamps.
        """
        pass


class TableComponent(ComponentClass):
    """
    This is the abstract base class for all table data component classes.
    """
    defaults: Dict[str, Any] = {"sample_id_column": None,
                                "columns_to_include": None,
                                "column_categorical": {},
                                "datetime_column": {}}
    forbidden_column_names = [dh.SAMPLE_IDS]

    def __init__(
            self, comp: Dict[str, Any], dataset_dir_path: str, batch_size: int,
            logging_purpose: struc_log.LoggingPurpose) -> None:
        super().__init__(comp, dataset_dir_path, batch_size, logging_purpose)
        self.allowed_file_types: List[str] = [".csv"]
        self.columns: List[str] = []
        self.dtypes: Dict[str, str] = {}
        return None

    def _check_forbidden_column_names(self) -> None:
        """Check whether any of the column names is in the list of forbidden
        column names and raise an exception if yes.
        """
        for c in self.columns:
            if c in TableComponent.forbidden_column_names:
                raise DSSFErrors.ColumnHeaderError(
                    f"`{c}` is not allowed as a column name. The following "
                    "names are reserved for internal use and can therefore "
                    "not be used as column names: "
                    f"{', '.join(TableComponent.forbidden_column_names)}.")
        return None

    def _check_enforced_categorical_names(self) -> None:
        """Check whether in the optional info for categorical columns, there
        are inexistent column names.
        """
        # Check if columns, whose type (categorical or not) are enforced, are
        # valid column names.
        if "column_categorical" in self.opt_info:
            cols_enforced = list(self.opt_info["column_categorical"])
            cols_enforced_invalid = [col for col in cols_enforced
                                     if col not in self.columns]
            if cols_enforced_invalid != []:
                msg = ("The following entries of 'column_categorical' are "
                       "invalid column names: "
                       f"{', '.join(cols_enforced_invalid)}")
                raise DSSFErrors.DSSFNodesMissing(msg)
        return None

    def _check_type_opt_info(self, info: str) -> bool:
        """Used to test that the value of the optional key is valid.

        Args:
            info (str): name of optional key to test

        Returns:
            bool: true if it is valid
        """
        if info == "sample_id_column":
            return (self.opt_info[info] is None or
                    (isinstance(self.opt_info[info], (str, int))))
        elif info == "columns_to_include":
            return (self.opt_info[info] is None or
                    all(isinstance(elem, (str, int))
                        for elem in self.opt_info[info]))
        elif info == "column_categorical":
            return (isinstance(self.opt_info[info], dict) and
                    all(isinstance(elem, bool)
                        for elem in self.opt_info[info].values()))
        elif info == "datetime_column":
            return (isinstance(self.opt_info[info], dict) and
                    all(isinstance(elem, bool)
                        for elem in self.opt_info[info].values()))
        return False

    def save_component(self, h5_writer: dh.DatasetWriter,
                       shuffled_positions: List[int],
                       nodes_to_be_saved: Optional[List[str]]) -> None:
        """Use the generator to read all data and save it in the given sequence.

        The list `shuffled_positions` describes the way the data is shuffled.
        The `n`th entry is the index of the input data sample which is saved at
        position `n` in the internal dataset.

        Args:
            h5_writer (dh.DatasetWriter): h5 datahandler writer instance
            shuffled_positions (List[int]): sequence to save the data
            nodes_to_be_saved (Optional[List[str]]): None if all data should be
                saved, else the names of the nodes that should be saved
        """
        if self.sample_ids == []:
            self.prepare_data_for_reading()
        shuffling_dict = {x: n for n, x in enumerate(shuffled_positions)}
        # Check which columns are to be saved and adapt self.columns.
        self._prepare_columns_to_save(nodes_to_be_saved)
        if self.columns == []:
            self.component_logger.log_warning(
                f"No nodes are saved for table '{self.name}' "
                "as there are none of the in the list of nodes"
                " to be saved!")
            return None
        if self.opt_info["datetime_column"]:
            for time_col in self.opt_info["datetime_column"]:
                if (self.opt_info["datetime_column"][time_col]
                        and time_col in self.columns):
                    self._save_datetime(time_col, shuffling_dict, h5_writer)
                    # Remove the timestamp from the columns to save.
                    self.columns.remove(time_col)

        # Metadata preparation.
        self._prepare_empty_metadata()
        for col in self.columns:
            self.metadata[col].dssf_component_file_path.set(
                self.path if not isinstance(self.path, list)
                else sorted(self.path)[0]
            )
            self.metadata[col].dssf_component_name.set(self.name)

        counter = 0
        unique_values: Dict[str, List] = {i: [] for i in self.columns}
        is_cat: Dict[str, bool] = {i: True for i in self.columns}
        max_value: Dict[str, Union[float, int]] = {}
        min_value: Dict[str, Union[float, int]] = {}
        n_samples = len(self.sample_ids)
        n_columns = len(self.columns)
        n_cells_total = n_samples * n_columns
        n_cells_filled = 0
        self.component_logger.log_name()
        for batch in self.data_generator:
            for col in self.columns:
                n = counter
                col_dict: Dict[int, Any] = {}
                for value in batch[col]:
                    col_dict[shuffling_dict[n]] = value
                    n += 1
                if counter == 0:
                    max_value[col] = (max(col_dict.values())
                                      if self.dtypes[col] == "num" else -1)
                    min_value[col] = (min(col_dict.values())
                                      if self.dtypes[col] == "num" else -1)
                    # The optional info field `column_categorical` is a
                    # dictionary with bools. True means, the respective column
                    # is categorical, False means it is not categorical.
                    # Columns that are not in this dictionary, are inferred.
                    if "column_categorical" in self.opt_info \
                            and col in self.opt_info["column_categorical"]:
                        is_cat[col] = self.opt_info["column_categorical"][col]
                    else:
                        is_cat[col] = dssf_utils.test_categorical(
                            list(col_dict.values()))
                    node_type = self.dtypes[col] + is_cat[col] * "_cat"
                    self.metadata[col].dssf_component_type.set(self.type)
                    self.metadata[col].upload_node_type.set(node_type)
                    self.metadata[col].upload_node_name.set(col)
                    self.metadata[col].node_type.set(node_type)
                    self.metadata[col].upload_node_dim.set([1])
                    self.metadata[col].node_dim.set([1])
                if is_cat[col]:
                    unique_values[col].extend(list(set(col_dict.values())))
                    unique_values[col] = list(set(unique_values[col]))
                if self.dtypes[col] == "num":
                    if max(col_dict.values()) > max_value[col]:
                        max_value[col] = max(col_dict.values())
                    if min(col_dict.values()) < min_value[col]:
                        min_value[col] = min(col_dict.values())
                h5_writer.add_dict_to_node(col_dict, col)
                n_cells_filled += len(list(col_dict.keys()))
                self.component_logger.log_percentage(
                    float(n_cells_filled) / n_cells_total * 100)
            counter = n
        for col in self.columns:
            if is_cat[col]:
                self.metadata[col].upload_nr_categories.set(
                    len(unique_values[col])
                )
                self.metadata[col].nr_categories.set(len(unique_values[col]))
                self.metadata[col].upload_unique_categories.set(
                    unique_values[col]
                )
                self.metadata[col].unique_categories.set(unique_values[col])
            if self.dtypes[col] == "num":
                self.metadata[col].upload_max.set(max_value[col])
                self.metadata[col].max.set(max_value[col])
                self.metadata[col].upload_min.set(min_value[col])
                self.metadata[col].min.set(min_value[col])
            meta_handler.PropertiesWriter().write_to_ds_writer(
                self.metadata[col], col, h5_writer)
        return None

    def _prepare_columns_to_save(
            self, nodes_to_be_saved: Optional[List[str]]) -> None:
        """Filter out the columns given in the DSSF or the DSSFSaver.

        Args:
            nodes_to_be_saved (Optional[List[str]]): None if all data should be
                saved based on the DSSFSaver, else the names of the nodes that
                should be saved.

        Raises:
            DSSFErrors.DSSFNodesMissing: Raised if a node name given by the
                user is not in the table.
        """
        # List of nodes given by the user in the DSSF.
        cols_to_include_dssf: Optional[List[str]] = \
            self.opt_info["columns_to_include"]
        if cols_to_include_dssf is not None:
            invalid_col_names = [col for col in cols_to_include_dssf
                                 if col not in self.columns]
            if invalid_col_names != []:
                msg = ("The following entries of 'columns_to_include' are "
                       f"missing: {', '.join(invalid_col_names)}")
                raise DSSFErrors.DSSFNodesMissing(msg)
        self._check_enforced_categorical_names()
        # Add to the list given by the DSSFSaver (for example to ignore the
        # label in the predictions).
        if (nodes_to_be_saved is not None or
                cols_to_include_dssf is not None):
            if nodes_to_be_saved is None:
                nodes_to_be_saved = cols_to_include_dssf
            elif cols_to_include_dssf is None:
                pass
            else:
                nodes_to_be_saved = list(
                    set(nodes_to_be_saved).intersection(cols_to_include_dssf))
        if nodes_to_be_saved is not None:
            self.columns = [i for i in self.columns if i in nodes_to_be_saved]
        # Pop sample_id column (we don't save them here).
        if self.opt_info["sample_id_column"] is not None:
            self.columns = [i for i in self.columns
                            if i != self.opt_info["sample_id_column"]]
        return None

    @abstractmethod
    def _get_time_stamp(self, col_name: str) -> List[np.datetime64]:
        """Get the time stamp from a csv using the reader.

        Args:
            col_name (str): Name of the column containing the time stamp.

        Returns:
            List[np.datetime64]: List of all time stamps.
        """
        pass

    def _prepare_empty_metadata(self) -> None:
        """Prepare the metadata dictionary for each column entry.
        """
        for col in self.columns:
            self.metadata[col] = meta_prop.AllProperties()
        return None


class SingleNodeComponent(ComponentClass):
    """
    This class represent component with a single node (like images, numpy files
    or texts). Every sample has its own file.
    """
    defaults = {"categorical": None}

    def __init__(
            self, comp: Dict[str, Any], dataset_dir_path: str, batch_size: int,
            logging_purpose: struc_log.LoggingPurpose) -> None:
        super().__init__(comp, dataset_dir_path, batch_size, logging_purpose)
        self.batch_size = batch_size
        self.paths: List[str] = []
        self.allowed_file_types = (
            [".txt", ".jpg", ".npy", ".tif", ".png"] if comp["type"] == "num"
            else [".txt"] if comp["type"] == "str"
            else [".txt", ".npy"])
        self.metadata[self.name] = meta_prop.AllProperties()

    def _check_type_opt_info(self, info: str) -> bool:
        """Used to test that the value of the optional key is valid.

        Args:
            info (str): name of optional key to test

        Returns:
            bool: true if it is valid
        """
        if info == "categorical":
            return (isinstance(self.opt_info[info], bool) or
                    self.opt_info[info] is None)
        return False

    def prepare_data_for_reading(self) -> int:
        """Prepare the generator to read the data.

        Check if the data is correct and get the sample ids and paths.

        Raises:
            FileNotFoundError: Raised if no files were found for the path
                given by the user.

        Returns:
            int: number of samples
        """
        self._check_file_extension()
        abs_path = os.path.join(self.dataset_dir_path, self.path)
        abs_path = abs_path.replace(ID_PLACEHOLDER, "*")
        self.paths = glob.glob(abs_path)
        if len(self.paths) == 0:
            raise FileNotFoundError("There are no files matching the "
                                    f"description '{self.path}' "
                                    f"for component '{self.name}'!")
        self.metadata[self.name].dssf_component_file_path.set(self.path)
        self.metadata[self.name].dssf_component_name.set(self.name)
        self.sample_ids = self._get_sample_ids_from_paths(self.paths)
        return len(self.sample_ids)

    def save_component(self, h5_writer: dh.DatasetWriter,
                       shuffled_positions: List[int],
                       nodes_to_be_saved: Optional[List[str]]) -> None:
        """Use the generator to read all data and save it in the given sequence.

        The list `shuffled_positions` describes the way the data is shuffled.
        The `n`th entry is the index of the input data sample which is saved at
        position `n` in the internal dataset.

        Args:
            h5_writer (dh.DatasetWriter): h5 datahandler writer instance
            shuffled_positions (List[int]): sequence to save the data
            nodes_to_be_saved (Optional[List[str]]): None if all data should be
                saved, else the names of the nodes that should be saved

        Raises:
            DSSFErrors.WrongTypeError: The data has another type as specified
                in the dssf.
            DSSFErrors.DataShapeMissmatchError: Not all data has the same
                shape.
        """
        if self.sample_ids == []:
            self.prepare_data_for_reading()
        if self.batch_size == -1:
            self.batch_size = 100
        counter = 0
        if (nodes_to_be_saved is not None and
                self.name not in nodes_to_be_saved):
            self.component_logger.log_warning(
                f"Node {self.name} not saved as it is not in the "
                "list of nodes to be saved.")
            return None

        # Prepare and validate data.
        path = self.paths[shuffled_positions[0]]
        reader = read_data.read_data(path)
        dtype: str = reader.get_dtypes()
        if dtype != self.type:
            if dtype == "num" and self.type == "str":
                data = np.atleast_1d(reader.get_data()).astype(str)
            elif not self.type == "datetime":
                # The datetime type is tested later in `save_datetime`.
                raise DSSFErrors.WrongTypeError(
                    f"The data of node {self.name} has type '{dtype}' and"
                    f" not '{self.type}' as indicated in the dssf!")
        else:
            data = np.atleast_1d(reader.get_data())
        shape = reader.get_shape()
        if shape == [1]:
            is_single_value = True
        else:
            is_single_value = False
        if self.type == "num":
            max_value = np.amax(data)
            min_value = np.amin(data)
        unique_values: List = []
        shape = reader.get_shape()
        self.component_logger.log_name()

        # Special case datetime.
        if self.type == "datetime":
            shuffling_dict = {x: n for n, x in enumerate(shuffled_positions)}
            self._save_datetime(self.name, shuffling_dict, h5_writer)
            return None
        # The two types 'str' and 'num' follow.
        # Iterate over all batches.
        for i in range((len(shuffled_positions) + self.batch_size - 1)
                       // self.batch_size):
            data_batch: List[np.ndarray] = []

            end = (counter + self.batch_size
                   if counter + self.batch_size <= len(shuffled_positions)
                   else len(shuffled_positions))
            for n in range(counter, end):
                # Get the sample which is saved at position n in the internal
                # dataset.
                path = self.paths[shuffled_positions[n]]
                reader = read_data.read_data(path)
                shape_n = reader.get_shape()
                if shape_n != shape:
                    raise DSSFErrors.DataShapeMissmatchError(
                        "Shapes of data within one node must be the same!")
                dtype = reader.get_dtypes()
                if dtype != self.type:
                    if dtype == "num" and self.type == "str":
                        data = np.atleast_1d(reader.get_data()).astype(str)
                    else:
                        raise DSSFErrors.WrongTypeError(
                            f"The data of node {self.name} has type '{dtype}' "
                            f"and not '{self.type}' as indicated in the dssf!")
                else:
                    data = reader.get_data()
                data_batch.append(data)

            if i == 0:
                if self.opt_info["categorical"] is not None:
                    is_cat = self.opt_info["categorical"]
                else:
                    is_cat = dssf_utils.test_categorical(data_batch)
                node_type = dtype + is_cat * "_cat"
                self.metadata[self.name].dssf_component_type.set(self.type)
                self.metadata[self.name].upload_node_type.set(node_type)
                self.metadata[self.name].upload_node_name.set(self.name)
                self.metadata[self.name].node_type.set(node_type)
                self.metadata[self.name].upload_node_dim.set(shape)
                self.metadata[self.name].node_dim.set(shape)
            if is_cat and is_single_value:
                unique_values.extend(list(set(data_batch)))
                unique_values = list(set(unique_values))
            if dtype == "num":
                max_value_of_batch = np.amax(np.array(data_batch))
                min_value_of_batch = np.amin(np.array(data_batch))
                if max_value_of_batch > max_value:
                    max_value = max_value_of_batch
                if min_value_of_batch < min_value:
                    min_value = min_value_of_batch

            counter = end
            # Write the batch to the internal dataset.
            h5_writer.add_data_to_node(self.name, np.array(data_batch))
            self.component_logger.log_percentage(
                float(counter) / len(shuffled_positions) * 100)

        if is_cat:
            self.metadata[self.name].upload_nr_categories.set(
                len(unique_values))
            self.metadata[self.name].nr_categories.set(
                len(unique_values))
            self.metadata[self.name].upload_unique_categories.set(
                unique_values)
            self.metadata[self.name].unique_categories.set(unique_values)
        if dtype == "num":
            self.metadata[self.name].upload_max.set(max_value)
            self.metadata[self.name].max.set(max_value)
            self.metadata[self.name].upload_min.set(min_value)
            self.metadata[self.name].min.set(min_value)
        meta_handler.PropertiesWriter().write_to_ds_writer(
            self.metadata[self.name], self.name, h5_writer
        )
        return None

    def _get_time_stamp(self, name: str) -> List[np.datetime64]:
        """Get the time stamp from component using the reader.

        Args:
            name (str): Name of the column or component containing the
                timestamp.

        Returns:
            List[np.datetime64]: List of all time stamps.
        """
        data: List = []
        for path in self.paths:
            reader = read_data.read_data(path)
            data.append(reader.get_data())
        if all((isinstance(entry, np.ndarray) and
                np.issubdtype(entry.dtype, np.datetime64)
                for entry in data)):
            return data
        else:
            df = pd.DataFrame({"datetime": data})
            datetime_utils.parse_datetime_in_dataframe_column(df, "datetime")
            return list(df["datetime"].values)


class TableComponentOneFilePerSample(TableComponent):
    """This class class represents tables with one file per sample.
    """
    def __init__(
            self, comp: Dict[str, Any], dataset_dir_path: str, batch_size: int,
            logging_purpose: struc_log.LoggingPurpose) -> None:
        super().__init__(comp, dataset_dir_path, batch_size, logging_purpose)
        self.batch_size = batch_size
        self.paths: List[str] = []
        return None

    def prepare_data_for_reading(self) -> int:
        """Prepare the generator to read the data.

        Check if the data is correct and get the sample ids and paths.

        Raises:
            DSSFErrors.ColumnOverflowException: Raised if there are more
                columns than the upper limit defined in COLUMN_LIMIT.
            FileNotFoundError: Raised if no files were found for the path
                given by the user.


        Returns:
            int: number of samples
        """
        self._check_file_extension()
        abs_path = os.path.join(self.dataset_dir_path, self.path)
        abs_path = abs_path.replace(ID_PLACEHOLDER, "*")
        self.paths = glob.glob(abs_path)
        if len(self.paths) == 0:
            raise FileNotFoundError("There are no files matching the "
                                    f"description '{self.path}' "
                                    f"for component '{self.name}'!")
        self.sample_ids = self._get_sample_ids_from_paths(self.paths)
        reader = read_data.read_data(self.paths[0])
        self.columns = reader.columns
        self._check_forbidden_column_names()
        if len(self.columns) > COLUMN_LIMIT:
            raise DSSFErrors.ColumnOverflowException(
                "The upper limit for number of columns in a csv for "
                f"AutoML is '{COLUMN_LIMIT}'. This .csv has "
                f"'{len(self.columns)}' columns!")
        self.dtypes = reader.get_dtypes()
        # Check if there is a datetime stamp.
        if AUTOMATIC_DATETIME_HEURISTIC_ON:
            for col in self.columns:
                if (col in self.opt_info["datetime_column"]
                        or self.dtypes[col] == "num"):
                    continue
                if reader.check_if_datetime_col(col):
                    self.opt_info["datetime_column"][col] = True
        self._prepare_empty_metadata()
        for col in self.columns:
            self.metadata[col].dssf_component_file_path.set(self.path)
            self.metadata[col].dssf_component_name.set(self.name)
        return len(self.sample_ids)

    def save_component(self, h5_writer: dh.DatasetWriter,
                       shuffled_positions: List[int],
                       nodes_to_be_saved: Optional[List[str]]) -> None:
        """Use the generator to read all data and save it in the given sequence.

        The list `shuffled_positions` describes the way the data is shuffled.
        The `n`th entry is the index of the input data sample which is saved at
        position `n` in the internal dataset.

        Args:
            h5_writer (dh.DatasetWriter): h5 datahandler writer instance
            shuffled_positions (List[int]): sequence to save the data
            nodes_to_be_saved (Optional[List[str]]): None if all data should be
                saved, else the names of the nodes that should be saved

        Raises:
            DSSFErrors.DataShapeError: Raised if the csv has more than one
                sample.
        """
        if self.columns == []:
            self.prepare_data_for_reading()
        if self.batch_size == -1:
            self.batch_size = compute_component_batch_size(
                BATCH_SIZE_GB, self.paths, len(self.sample_ids))
        self._prepare_columns_to_save(nodes_to_be_saved)
        if self.columns == []:
            self.component_logger.log_warning(
                f"No nodes are saved for table '{self.name}' "
                "as there are none of the in the list of nodes"
                " to be saved!")
            return None
        if self.opt_info["datetime_column"]:
            for time_col in self.opt_info["datetime_column"]:
                if (self.opt_info["datetime_column"][time_col]
                        and time_col in self.columns):
                    shuffling_dict = {x: n for n, x in enumerate(
                        shuffled_positions)}
                    self._save_datetime(time_col,
                                        shuffling_dict, h5_writer)
                    # Remove the timestamp of the columns to save.
                    self.columns.remove(time_col)

        counter = 0
        unique_values: Dict[str, List] = {i: [] for i in self.columns}
        is_cat: Dict[str, bool] = {i: True for i in self.columns}
        self.component_logger.log_name()
        for i in range((len(shuffled_positions) + self.batch_size - 1)
                       // self.batch_size):
            data_batch: Dict[str, List] = {i: [] for i in self.columns}
            end = (counter + self.batch_size
                   if counter + self.batch_size <= len(self.sample_ids)
                   else len(self.sample_ids))
            for n in range(counter, end):
                path = self.paths[shuffled_positions[n]]
                reader = read_data.read_data(path)
                if reader.get_shape()[0] != 1:
                    raise DSSFErrors.DataShapeError(
                        "CSV is only allowed to have one line. This csv has "
                        f"{reader.get_shape()[0]}!")
                data = reader.get_data()
                for col in self.columns:
                    data_batch[col].extend(data[col])
            if counter == 0:
                max_value = {i: max(data_batch[i]) if self.dtypes[i] == "num"
                             else -1 for i in self.columns}
                min_value = {i: max(data_batch[i]) if self.dtypes[i] == "num"
                             else -1 for i in self.columns}
            for col in self.columns:
                h5_writer.add_data_to_node(col,
                                           np.array(data_batch[col]))
                if self.dtypes[col] == "num":
                    if max(data_batch[col]) > max_value[col]:
                        max_value[col] = max(data_batch[col])
                    if min(data_batch[col]) < min_value[col]:
                        min_value[col] = min(data_batch[col])
                if counter == 0:
                    # The optional info field `column_categorical` is a
                    # dictionary with bools. True means, the respective column
                    # is categorical, False means it is not categorical.
                    # Columns that are not in this dictionary, are inferred.
                    if "column_categorical" in self.opt_info \
                            and col in self.opt_info["column_categorical"]:
                        is_cat[col] = self.opt_info["column_categorical"][col]
                    else:
                        is_cat[col] = dssf_utils.test_categorical(
                            data_batch[col])
                    node_type = self.dtypes[col] + is_cat[col] * "_cat"
                    self.metadata[col].dssf_component_type.set(self.type)
                    self.metadata[col].upload_node_type.set(node_type)
                    self.metadata[col].upload_node_name.set(col)
                    self.metadata[col].node_type.set(node_type)
                    self.metadata[col].upload_node_dim.set([1])
                    self.metadata[col].node_dim.set([1])
                if is_cat[col]:
                    unique_values[col].extend(list(set(data_batch[col])))
                    unique_values[col] = list(set(unique_values[col]))
            counter = end
            self.component_logger.log_percentage(
                counter / len(shuffled_positions) * 100)
        for col in self.columns:
            if is_cat[col]:
                self.metadata[col].upload_nr_categories.set(
                    len(unique_values[col])
                )
                self.metadata[col].nr_categories.set(len(unique_values[col]))
                self.metadata[col].upload_unique_categories.set(
                    unique_values[col]
                )
                self.metadata[col].unique_categories.set(unique_values[col])
            if self.dtypes[col] == "num":
                self.metadata[col].upload_max.set(max_value[col])
                self.metadata[col].max.set(max_value[col])
                self.metadata[col].upload_min.set(min_value[col])
                self.metadata[col].min.set(min_value[col])
            meta_handler.PropertiesWriter().write_to_ds_writer(
                self.metadata[col], col, h5_writer
            )
        return None

    def _get_time_stamp(self, col_name) -> List[np.datetime64]:
        """Get the time stamp from a csv using the reader.

        Args:
            col_name (str): Name of the column containing the time stamp.

        Raises:
            DSSFErrors.DSSFDateTimeNotReadable: Time stamp not parsable.

        Returns:
            List[np.datetime64]: List of all time stamps.
        """
        readers = [read_data.read_data(p) for p in self.paths]
        try:
            time_stamps: List[np.datetime64] = []
            for r in readers:
                time_stamps.extend(r.get_datetime_data_column(col_name))
        except DSSFErrors.DSSFDateTimeNotReadable as err:
            msg = f"Node '{col_name}': DateTime not readable"
            self.component_logger.log_error(f"{msg}: {err}")
            raise DSSFErrors.DSSFDateTimeNotReadable(msg)
        return time_stamps


class TableComponentSingleFile(TableComponent):
    """This class reads and processes table data from a single file.
    """
    def __init__(
            self, comp: Dict[str, Any], dataset_dir_path: str, batch_size: int,
            logging_purpose: struc_log.LoggingPurpose) -> None:
        super().__init__(comp, dataset_dir_path, batch_size, logging_purpose)
        return None

    def prepare_data_for_reading(self) -> int:
        """Prepare the generator to read the data.

        Check if the data is correct and prepare the batches and generator.

        Raises:
            DSSFErrors.ColumnOverflowException: Raised if there are more
                columns than the upper limit defined in COLUMN_LIMIT.
            FileNotFoundError: The csv file containing the table is missing.
            DSSFErrors.SampleIDError: No unique sample_ids.
            DSSFErrors.DSSFOptionalKeyError: Sample id column not found in
                the saved columns of the table.

        Returns:
            int: number of samples
        """
        self._check_file_extension()
        path = os.path.join(self.dataset_dir_path, self.path)
        if not os.path.isfile(path):
            raise FileNotFoundError(f"There is no file '"
                                    f"{self.path}' "
                                    f"for component '{self.name}'!")
        reader = read_data.read_data(path)
        self.columns: List[str] = reader.columns
        self._check_forbidden_column_names()
        if len(self.columns) > COLUMN_LIMIT:
            raise DSSFErrors.ColumnOverflowException(
                "The upper limit for number of columns in a csv for "
                f"AutoML is '{COLUMN_LIMIT}'. This component has "
                f"'{len(self.columns)}' columns!")
        self.dtypes = reader.get_dtypes()
        sample_id_column = self.opt_info["sample_id_column"]
        # Check if there is a datetime stamp.
        if AUTOMATIC_DATETIME_HEURISTIC_ON:
            for col in self.columns:
                if (col in self.opt_info["datetime_column"] or
                        col == sample_id_column or self.dtypes[col] == "num"):
                    continue
                if reader.check_if_datetime_col(col):
                    self.opt_info["datetime_column"][col] = True

        if sample_id_column in self.columns:
            self.sample_ids = list(map(str, reader.get_data_single_column(
                sample_id_column)))
            if len(self.sample_ids) != len(set(self.sample_ids)):
                msg = (f"The sample_ids in column '{sample_id_column}' are not"
                       " unique!")
                self.component_logger.log_error(msg)
                raise DSSFErrors.SampleIDError(msg)
        else:
            if sample_id_column is not None:
                msg = (f"Sample_id column '{sample_id_column}' not found in "
                       "table!")
                self.component_logger.log_error(msg)
                raise DSSFErrors.DSSFOptionalKeyError(msg)

            self.sample_ids = [str(i) for i in range(reader.len)]
        if self.batch_size == -1:
            self.batch_size = compute_component_batch_size(
                BATCH_SIZE_GB, [path], len(self.sample_ids))
        self.data_generator = reader.get_data_in_batches(self.batch_size)
        return reader.len

    def _get_time_stamp(self, col_name) -> List[np.datetime64]:
        """Get the time stamp from a csv using the reader.

        Args:
            col_name (str): Name of the column containing the time stamp.

        Raises:
            DSSFErrors.DSSFDateTimeNotReadable: Time stamp not parsable.

        Returns:
            List[np.datetime64]: List of all time stamps.
        """
        path = os.path.join(self.dataset_dir_path, self.path)
        reader = read_data.read_data(path)
        try:
            time_stamps = reader.get_datetime_data_column(col_name)
        except DSSFErrors.DSSFDateTimeNotReadable as err:
            msg = f"Node '{col_name}': DateTime not readable"
            self.component_logger.log_error(f"{msg}: {err}")
            raise DSSFErrors.DSSFDateTimeNotReadable(msg)
        return time_stamps


class TableComponentMultiFile(TableComponent):
    """This class reads and processes table data from more than one file.
    """
    def __init__(
            self, comp: Dict[str, Any], dataset_dir_path: str, batch_size: int,
            logging_purpose: struc_log.LoggingPurpose) -> None:
        super().__init__(comp, dataset_dir_path, batch_size, logging_purpose)
        return None

    def prepare_data_for_reading(self) -> int:
        """Prepare the generator to read the data.

        Check if the data is correct and prepare the batches and generator.

        Raises:
            DSSFErrors.ColumnOverflowException: Raised if there are more
                columns than the upper limit defined in COLUMN_LIMIT.
            FileNotFoundError: The csv file containing the table is missing.
            DSSFErrors.SampleIDError: No unique sample_ids.
            DSSFErrors.DSSFOptionalKeyError: Sample id column not found in
                the saved columns of the table.
            DSSFErrors.ColumnHeaderError: Raised if the csv do not have the
                same header.

        Returns:
            int: number of samples
        """
        self._check_file_extension()
        paths = [os.path.join(self.dataset_dir_path, p) for p in self.path]
        for abs_path, rel_path in zip(paths, self.path):
            if not os.path.isfile(abs_path):
                raise FileNotFoundError(f"There is no file '"
                                        f"{rel_path}' "
                                        f"for component '{self.name}'!")
        readers = [read_data.read_data(p) for p in paths]
        self.columns: List[str] = readers[0].columns
        self._check_forbidden_column_names()
        if len(self.columns) > COLUMN_LIMIT:
            raise DSSFErrors.ColumnOverflowException(
                "The upper limit for number of columns in a csv for "
                f"AutoML is '{COLUMN_LIMIT}'. This component has "
                f"'{len(self.columns)}' columns!")
        self.dtypes = readers[0].get_dtypes()
        for r in readers:
            if r.columns != self.columns:
                raise DSSFErrors.ColumnHeaderError(
                    "Split csv need the same header, but "
                    "there are two different ones: "
                    f"'{self.columns}' != '{r.columns}'!")
        sample_id_column = self.opt_info["sample_id_column"]
        # Check if there is a datetime stamp.
        if AUTOMATIC_DATETIME_HEURISTIC_ON:
            for col in self.columns:
                if (col in self.opt_info["datetime_column"] or
                        col == sample_id_column or self.dtypes[col] == "num"):
                    continue
                if readers[0].check_if_datetime_col(col):
                    self.opt_info["datetime_column"][col] = True

        if sample_id_column in self.columns:
            self.sample_ids = [str(i) for r in readers
                               for i in r.get_data_single_column(
                                   sample_id_column)]
            if len(self.sample_ids) != len(set(self.sample_ids)):
                msg = (f"The sample_ids in column '{sample_id_column}' are not"
                       " unique!")
                self.component_logger.log_error(msg)
                raise DSSFErrors.SampleIDError(msg)
        else:
            if sample_id_column is not None:
                msg = (f"Sample_id column '{sample_id_column}' not found in "
                       "table!")
                self.component_logger.log_error(msg)
                raise DSSFErrors.DSSFOptionalKeyError(msg)
            self.sample_ids = [
                    str(i) for i in range(sum([r.len for r in readers]))
                ]
        if self.batch_size == -1:
            self.batch_size = compute_component_batch_size(
                BATCH_SIZE_GB, paths, len(self.sample_ids))
        self.data_generator = itertools.chain(
            *[r.get_data_in_batches(self.batch_size) for r in readers])
        return sum([r.len for r in readers])

    def _get_time_stamp(self, col_name) -> List[np.datetime64]:
        """Get the time stamp from a csv using the reader.

        Args:
            col_name (str): Name of the column containing the time stamp.

        Raises:
            DSSFErrors.DSSFDateTimeNotReadable: Time stamp not parsable.

        Returns:
            List[np.datetime64]: List of all time stamps.
        """
        paths = [os.path.join(self.dataset_dir_path, p) for p in self.path]
        readers = [read_data.read_data(p) for p in paths]
        try:
            time_stamps: List[np.datetime64] = []
            for r in readers:
                time_stamps.extend(r.get_datetime_data_column(col_name))
        except DSSFErrors.DSSFDateTimeNotReadable as err:
            msg = f"Node '{col_name}': DateTime not readable"
            self.component_logger.log_error(f"{msg}: {err}")
            raise DSSFErrors.DSSFDateTimeNotReadable(msg)
        return time_stamps
