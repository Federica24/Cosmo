# (C) Modulos AG (2019-2020). All rights reserved.
"""This file contains the code used preparing the data for the online client.
At the moment this only contains the datetime preparation."""

from typing import Dict

from modulos_utils.solution_utils import datetime


def preprocess(sample_dict: Dict, metadata_path: str) -> Dict:
    """Preprocess the data. At the moment only compute the datetime features.

    Args:
        sample_dict (Dict): sample to compute
        metadata_path (str): path to the metadata of the sample

    Returns:
        Dict: Copy of sample_dict with the datetime features added.
    """
    # Add the datetime features to the sample.
    new_dict = dict(sample_dict)
    datetime.add_datetime_features(new_dict, metadata_path)
    return new_dict
