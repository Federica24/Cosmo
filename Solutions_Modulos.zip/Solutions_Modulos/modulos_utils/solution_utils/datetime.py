# (C) Modulos AG (2019-2020). All rights reserved.
"""This file contains the code used for the datetime in assembling the solution
folder."""

import logging
import pandas as pd
from typing import List, Dict

from modulos_utils.datetime_utils import datetime_utils
from modulos_utils.solution_utils import utils as su


def get_datetime_node_names(metadata_path: str) -> List[str]:
    """Get the list of datetime nodes.

    Args:
        metadata_path (str): Path to the metadatafile.

    Returns:
        List[str]: List of node names containing datetime stamps.
    """
    node_names_upload = su.get_input_node_names(metadata_path, generated=False)
    node_names_internal = su.get_input_node_names(
        metadata_path, generated=True)
    nodes_only_upload = [name for name in node_names_upload
                         if name not in node_names_internal]
    datetime_nodes = [name for name in nodes_only_upload
                      if all(feature in node_names_internal for feature
                             in datetime_utils.get_datetime_node_names(name))]
    return datetime_nodes


def add_datetime_features(sample_dict: Dict, metadata_path: str) -> None:
    """Compute the datetime features of a sample.

    Args:
        sample_dict (Dict): Dictionary of one sample.
        metadata_path (str): Path to the metadata.

    Raises:
        Exception: Failing to parse datetime.
    """
    time_nodes: List[str] = get_datetime_node_names(metadata_path)
    for time_node in time_nodes:
        time_col = pd.DataFrame({time_node: [sample_dict[time_node]]})
        try:
            datetime_utils.parse_datetime_in_dataframe_column(
                time_col, time_node)
            time_values = list(time_col[time_node].values)
            new_features = datetime_utils.\
                compute_features_from_timestamp(pd.to_datetime(time_values))
        except ValueError as err:
            msg = f"Could not read datetime node {time_node}!\n{err}"
            logging.error(msg)
            raise ValueError(msg)
        sample_dict.update(
            {datetime_utils.get_datetime_node_name_for_feature(
                time_node, name): new_features[name][0]
                for name in new_features})
        sample_dict.pop(time_node)
