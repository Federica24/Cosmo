# Check my DSSF

## Usage

```bash
    ~/automl$ python -m modulos_utils.dssf_validation.check_my_dssf --json path/to/dataset_structure.json
```

will check if the dssf-file (`path/to/dataset_structure.json`) is a valid json and if it has all the required keys.
